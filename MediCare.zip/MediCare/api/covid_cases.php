<?php 

include 'db2.php';

$query=mysqli_query($con,"SELECT * FROM covid_db join patient_detail on covid_db.patient_id=patient_detail.patient_id where covid_db.result=1");
$result= array();

while ($rowData= $query->fetch_assoc()) {
	$result[]= $rowData;
}

echo json_encode($result);

?>