<?php 

include 'db2.php';

  @$role = $_POST['roleid'];

  $query=mysqli_query($con,"SELECT * FROM `patient_detail` inner join role_db ON role_db.role_id=patient_detail.role_id WHERE role_db.role_id='$role'");
  $result= array();

  while ($rowData= $query->fetch_assoc()) {
	$result[]= $rowData;
  }

  echo json_encode($result);


?>