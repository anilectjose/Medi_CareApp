<?php

include "db2.php";

@$name=$_POST['names'];
@$pass=$_POST['password'];
 @$email = $_POST['mailid'];
 @$mobile = $_POST['phonen'];

$query="insert into role_db (mail,password,role) values ('$email','$pass','guest')";
$result = mysqli_query($con,$query);
$roleid =mysqli_insert_id($con);
$result2 =mysqli_query($con, "INSERT INTO `user_details`(`user_name`, `email`, `mobile`,`role_id`) VALUES ('$name','$email','$mobile','$roleid')");

if($result2){
	echo "done";
}
else{
	echo "error";
}

?>	