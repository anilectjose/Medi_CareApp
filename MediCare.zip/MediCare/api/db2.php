<?php
$con = new mysqli("localhost","root","","medi_care");

if($con){

}
else{
	echo "Connection Failed";
	exit();
}
?>