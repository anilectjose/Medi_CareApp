<?php 

include 'db2.php';

  @$roleid = $_POST['mailid'];
  @$Location = $_POST['Loca'];
  @$role = $_POST['role'];

  if($role=='ashaworker')
  {
    $sql2=mysqli_query($con,"UPDATE `ashaworker_db` SET `location_type`='$Location' WHERE role_id='$roleid'");
  }
  elseif ($role=='nurse') {
  	$sql2=mysqli_query($con,"UPDATE `nurse_db` SET `location_type`='$Location' WHERE role_id='$roleid'");
  }
  elseif ($role=='patient') {
  	  $sql2=mysqli_query($con,"UPDATE `patient_detail` SET `location_type`='$Location' WHERE role_id='$roleid'");
  }
  else{
  	$sql2=mysqli_query($con,"UPDATE `user_details` SET `location_type`='$Location' WHERE role_id='$roleid'");
  }

 
	
 		echo json_encode($json);
 		mysqli_close($con);


?>

  Future getValidationData() async {
    var url = Covid_19.BaseURL + "location.php";

    final SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
    var obtainEmail=sharedPreferences.getString('email');
    var obtainRole=sharedPreferences.getString('role');
    var obtainRoleid=sharedPreferences.getString('roleId');
    setState(() {
      finalEmail=obtainEmail;
      finalRole=obtainRole;
      finalRoleID=obtainRoleid;
    });
    print(finalEmail);
    print(finalRole);
    print(finalRoleID);

    final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    print(position);

    setState(() {
      _locationMessage = "${position.latitude}, ${position.longitude}";
    });
    print(_locationMessage);
    var credit = {"mailid": finalRoleID, "role": finalRole, "Loca": _locationMessage};

    http.Response res = await http.post(url, body: credit);

  }