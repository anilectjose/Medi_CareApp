<?php

include "db2.php";

@$name=$_POST['names'];
@$subj=$_POST['subject'];
@$compl = $_POST['complaint'];


$result = mysqli_query($con,"INSERT INTO complaint_db (name,subject,complaint) values ('$name','$subj','$compl')");

if($result){
	echo "done";
}
else{
	echo "error";
}

?>	