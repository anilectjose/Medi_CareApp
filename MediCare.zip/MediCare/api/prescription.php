<?php 

include 'db2.php';

@$id = $_POST['patid'];
@$record = $_POST['compid'];

$query=mysqli_query($con,"SELECT * FROM medicine_detail join patient_records ON medicine_detail.patient_id=patient_records.patient_id WHERE medicine_detail.patient_id='$id' AND patient_records.record_id='$record'");
$result= array();

while ($rowData= $query->fetch_assoc()) {
	$result[]= $rowData;
}

echo json_encode($result);

?>