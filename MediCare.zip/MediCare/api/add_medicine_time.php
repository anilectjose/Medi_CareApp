<?php

include "db2.php";

 @$med_id = $_POST['medicine_id'];
 @$meddate = $_POST['pdate'];
 @$medtime = $_POST['ptime'];


$result =mysqli_query($con, "UPDATE `medicine_detail` SET `date`='$meddate',`time`='$medtime' WHERE `medicine_id`='$med_id'");


if($result){
	echo "done";
}
else{
	echo "error";
}

?>	