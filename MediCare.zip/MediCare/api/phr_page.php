<?php 

include 'db2.php';

@$role = $_POST['roleid'];

  $query=mysqli_query($con,"SELECT * FROM `phr_db` inner join patient_detail ON patient_detail.patient_id=phr_db.patient_id WHERE patient_detail.role_id='$role'");

 $result= array();

while ($rowData= $query->fetch_assoc()) {
	$result[]= $rowData;
}

echo json_encode($result);


?>